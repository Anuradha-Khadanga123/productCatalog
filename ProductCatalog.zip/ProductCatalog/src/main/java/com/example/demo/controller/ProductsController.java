package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Exceptions.ResourceNotFoundException;
import com.example.demo.Exceptions.ValidationFailed;
import com.example.demo.dao.Products;
import com.example.demo.repo.ProductsRepo;

@RestController
@RequestMapping("/api/v1")
public class ProductsController {
	
	@Autowired
	private ProductsRepo productsrepo;
	
	@GetMapping("/allProducts")
	public List<Products> getAllProducts(){
		
		return productsrepo.findAll();
	}
	
	@PostMapping("/addProducts")
	public Products addProducts(@Valid @RequestBody Products products) throws ValidationFailed{
		
		Products addedproducts;
		
		try {
			addedproducts = productsrepo.save(products);
		} catch (Exception e) {
			throw new ValidationFailed("The request body conatains data which failed on validation.");
		}
		
		return addedproducts;
	}
	
	@GetMapping("/byType/{type}")
	public ResponseEntity<List<Products>> getProductsByType(@PathVariable(value="type") String type) throws ResourceNotFoundException{
		
		List<Products> productsByType = productsrepo.findByType(type);
		
		if(productsByType.isEmpty()) throw new ResourceNotFoundException("No products found by type : "+type);
		
		return ResponseEntity.ok().body(productsByType);
	}
	
	@GetMapping("/byBrand/{brand}")
	public ResponseEntity<List<Products>> getProductsByBrand(@PathVariable(value="brand") String brand) throws ResourceNotFoundException{
		
		List<Products> productsByBrand = productsrepo.findByBrand(brand);
		
		if(productsByBrand.isEmpty()) throw new ResourceNotFoundException("No products found by brand : "+brand);
		
		return ResponseEntity.ok().body(productsByBrand);
	}
	
	@GetMapping("/byColor/{color}")
	public ResponseEntity<List<Products>> getProductsByColor(@PathVariable(value="color") String color) throws ResourceNotFoundException{
		
		List<Products> productsByColor = productsrepo.findByColor(color);
		
		if(productsByColor.isEmpty()) throw new ResourceNotFoundException("No products found by color : "+color);
		
		return ResponseEntity.ok().body(productsByColor);
	}
	
	@GetMapping("/bySize/{size}")
	public ResponseEntity<List<Products>> getProductsBySize(@PathVariable(value="size") String size) throws ResourceNotFoundException{
		
		List<Products> productsBySize = productsrepo.findBySize(size);
		
		if(productsBySize.isEmpty()) throw new ResourceNotFoundException("No products found by size : "+size);
		
		return ResponseEntity.ok().body(productsBySize);
	}
	
	@GetMapping("/byPrice/{price}")
	public ResponseEntity<List<Products>> getProductsByPrice(@PathVariable(value="price") double price) throws ResourceNotFoundException{
		
		List<Products> productsByPrice = productsrepo.findByPrice(price);
		
		if(productsByPrice.isEmpty()) throw new ResourceNotFoundException("No products found by price : "+price);
		
		return ResponseEntity.ok().body(productsByPrice);
	}
	
	@GetMapping("/bySKU/{sku}")
	public ResponseEntity<List<Products>> getProductsBySKU(@PathVariable(value="sku") int sku) throws ResourceNotFoundException{
		
		List<Products> productsBySKU = productsrepo.findBySKU(sku);
		
		if(productsBySKU.isEmpty()) throw new ResourceNotFoundException("No products found by sku : "+sku);
		
		return ResponseEntity.ok().body(productsBySKU);
	}
}























