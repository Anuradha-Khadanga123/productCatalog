package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.dao.Products;



@Repository
public interface ProductsRepo extends JpaRepository<Products, Long> {
	
	@Query(value="Select * from Products where type=?1", nativeQuery = true)
	List<Products> findByType(String type);
	
	@Query(value="Select * from Products where brand=?1", nativeQuery = true)
	List<Products> findByBrand(String brand);
	
	@Query(value="Select * from Products where color=?1", nativeQuery = true)
	List<Products> findByColor(String color);
	
	@Query(value="Select * from Products where size=?1", nativeQuery = true)
	List<Products> findBySize(String size);
	
	@Query(value="Select * from Products where price=?1", nativeQuery = true)
	List<Products> findByPrice(double price);
	
	@Query(value="Select * from Products where sku=?1", nativeQuery = true)
	List<Products> findBySKU(int sku);
}
