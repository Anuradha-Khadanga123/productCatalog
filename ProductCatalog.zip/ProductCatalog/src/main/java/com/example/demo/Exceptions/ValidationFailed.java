package com.example.demo.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.NOT_FOUND)
public class ValidationFailed extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8521695424677169098L;
	
	public ValidationFailed(String message) {
		
		super(message);
	}

}
