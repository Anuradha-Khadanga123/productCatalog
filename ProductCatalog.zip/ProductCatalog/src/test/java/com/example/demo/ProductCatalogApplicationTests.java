package com.example.demo;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.dao.Products;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ProductCatalogApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProductCatalogApplicationTests {
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@LocalServerPort
	private int port;
	
	public String getRootURL() {
		
		return "/api/v1"+port;
	}

	@Test
	void contextLoads() {
	}
	

	
	public void testAddProducts() {
		
		Products addProducts = new Products();
		
		addProducts.setBrand("AllenSoly");
		addProducts.setColor("Black");
		addProducts.setType("Pant");
		addProducts.setSize("XL");
		addProducts.setPrice(1000);
		addProducts.setSku(12345);
		
		addProducts = restTemplate.postForObject(getRootURL()+"/addProducts", addProducts, Products.class);
		
		assertNotNull(addProducts);
	}
	
	@Test
	public void testGetAllProducts() {
		
		Products allProducts = restTemplate.getForObject(getRootURL()+"/allProducts", Products.class);
		
		assertNotNull(allProducts);
		
	}
	
	@Test
	public void testGetAllProductsByType() {
		
		Products allProductsByType = restTemplate.getForObject(getRootURL()+"//byType/Pant", Products.class);
		
		assertNotNull(allProductsByType);
		
	}
	
	@Test
	public void testGetAllProductsByBrand() {
		
		Products allProductsByBrand = restTemplate.getForObject(getRootURL()+"//byType/AllenSoly", Products.class);
		
		assertNotNull(allProductsByBrand);
		
	}
	
	@Test
	public void testGetAllProductsByColor() {
		
		Products allProductsByColor = restTemplate.getForObject(getRootURL()+"//byType/Black", Products.class);
		
		assertNotNull(allProductsByColor);
		
	}
	
	@Test
	public void testGetAllProductsBySize() {
		
		Products allProductsBySize = restTemplate.getForObject(getRootURL()+"//byType/XL", Products.class);
		
		assertNotNull(allProductsBySize);
		
	}
	
	@Test
	public void testGetAllProductsByPrice() {
		
		Products allProductsByPrice = restTemplate.getForObject(getRootURL()+"//byType/1000", Products.class);
		
		assertNotNull(allProductsByPrice);
		
	}
	
	@Test
	public void testGetAllProductsBySKU() {
		
		Products allProductsBySKU = restTemplate.getForObject(getRootURL()+"//byType/12345", Products.class);
		
		assertNotNull(allProductsBySKU);
		
	}

}
















